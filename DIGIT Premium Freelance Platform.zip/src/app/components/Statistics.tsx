import { useEffect, useState, useRef } from 'react';
import { motion, useInView } from 'motion/react';

interface StatProps {
  end: number;
  label: string;
  suffix?: string;
  prefix?: string;
}

function StatCounter({ end, label, suffix = '', prefix = '' }: StatProps) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (!isInView) return;

    const duration = 2000; // 2 seconds
    const steps = 60;
    const increment = end / steps;
    let current = 0;
    
    const timer = setInterval(() => {
      current += increment;
      if (current >= end) {
        setCount(end);
        clearInterval(timer);
      } else {
        setCount(Math.floor(current));
      }
    }, duration / steps);

    return () => clearInterval(timer);
  }, [end, isInView]);

  const formatNumber = (num: number) => {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(0) + 'K';
    }
    return num.toString();
  };

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, scale: 0.5 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5 }}
      className="text-center p-8 backdrop-blur-md bg-white/5 border border-green-500/20 rounded-3xl hover:bg-white/10 hover:border-green-500/40 hover:shadow-2xl hover:shadow-green-500/20 transition-all duration-300 group"
    >
      <motion.div
        className="text-5xl md:text-6xl font-bold mb-3 bg-gradient-to-r from-green-400 to-green-600 bg-clip-text text-transparent"
        animate={{ scale: isInView ? [1, 1.05, 1] : 1 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        {prefix}
        {suffix === '%' ? count : formatNumber(count)}
        {suffix}
      </motion.div>
      <div className="text-gray-400 text-lg font-medium group-hover:text-gray-300 transition-colors">
        {label}
      </div>
    </motion.div>
  );
}

export function Statistics() {
  const stats = [
    { end: 250000, label: 'Freelancers', suffix: '+' },
    { end: 50000, label: 'Companies', suffix: '+' },
    { end: 2000000, label: 'Projects Completed', suffix: '+' },
    { end: 98, label: 'Customer Satisfaction', suffix: '%' },
  ];

  return (
    <section className="relative py-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
            Trusted by Thousands Worldwide
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <StatCounter key={index} {...stat} />
          ))}
        </div>
      </div>
    </section>
  );
}
