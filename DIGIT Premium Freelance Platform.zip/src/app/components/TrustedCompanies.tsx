import { motion } from 'motion/react';

const companies = [
  'Airbnb',
  'Databricks',
  'Cloudflare',
  'Scale AI',
  'Microsoft',
  'Grammarly',
  'BambooHR',
  'Shutterstock',
];

export function TrustedCompanies() {
  return (
    <section className="relative py-20 overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-3xl md:text-4xl font-bold text-center mb-12 bg-gradient-to-r from-gray-200 to-green-400 bg-clip-text text-transparent"
        >
          Trusted by
        </motion.h2>

        <div className="relative">
          {/* Gradient overlays */}
          <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-black to-transparent z-10" />
          <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-black to-transparent z-10" />

          {/* Infinite scroll container */}
          <div className="flex overflow-hidden">
            <motion.div
              className="flex gap-16 items-center"
              animate={{
                x: [0, -1000],
              }}
              transition={{
                x: {
                  duration: 20,
                  repeat: Infinity,
                  ease: 'linear',
                },
              }}
            >
              {[...companies, ...companies, ...companies].map((company, index) => (
                <div
                  key={index}
                  className="flex-shrink-0 px-8 py-6 backdrop-blur-sm bg-white/5 border border-green-500/20 rounded-2xl hover:bg-white/10 hover:border-green-500/40 transition-all duration-300 group"
                >
                  <span className="text-2xl font-bold text-gray-400 group-hover:text-green-400 transition-colors whitespace-nowrap">
                    {company}
                  </span>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
