import { useEffect, useRef } from 'react';

export function AnimatedBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    const setCanvasSize = () => {
      canvas.width = window.innerWidth;
      canvas.height = document.documentElement.scrollHeight;
    };
    setCanvasSize();
    window.addEventListener('resize', setCanvasSize);

    // Particles
    const particles: Array<{
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;
    }> = [];

    for (let i = 0; i < 50; i++) {
      particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 3 + 1,
        speedX: Math.random() * 0.5 - 0.25,
        speedY: Math.random() * 0.5 - 0.25,
        opacity: Math.random() * 0.5 + 0.3,
      });
    }

    // Cubes
    const cubes: Array<{
      x: number;
      y: number;
      size: number;
      rotation: number;
      rotationSpeed: number;
      speedX: number;
      speedY: number;
      opacity: number;
    }> = [];

    for (let i = 0; i < 15; i++) {
      cubes.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 40 + 30,
        rotation: Math.random() * Math.PI * 2,
        rotationSpeed: (Math.random() - 0.5) * 0.02,
        speedX: Math.random() * 0.3 - 0.15,
        speedY: Math.random() * 0.3 - 0.15,
        opacity: Math.random() * 0.15 + 0.05,
      });
    }

    // Animation loop
    let animationId: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw grid
      ctx.strokeStyle = 'rgba(34, 197, 94, 0.05)';
      ctx.lineWidth = 1;
      const gridSize = 50;

      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }

      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // Draw and update particles
      particles.forEach((particle) => {
        ctx.fillStyle = `rgba(34, 197, 94, ${particle.opacity})`;
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#22C55E';
        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;

        particle.x += particle.speedX;
        particle.y += particle.speedY;

        if (particle.x < 0 || particle.x > canvas.width) particle.speedX *= -1;
        if (particle.y < 0 || particle.y > canvas.height) particle.speedY *= -1;
      });

      // Draw and update cubes
      cubes.forEach((cube) => {
        ctx.save();
        ctx.translate(cube.x + cube.size / 2, cube.y + cube.size / 2);
        ctx.rotate(cube.rotation);

        // Cube outline
        ctx.strokeStyle = `rgba(34, 197, 94, ${cube.opacity})`;
        ctx.lineWidth = 2;
        ctx.strokeRect(-cube.size / 2, -cube.size / 2, cube.size, cube.size);

        // Inner lines for 3D effect
        ctx.beginPath();
        ctx.moveTo(-cube.size / 2, -cube.size / 2);
        ctx.lineTo(cube.size / 4, cube.size / 4);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(cube.size / 2, -cube.size / 2);
        ctx.lineTo(-cube.size / 4, cube.size / 4);
        ctx.stroke();

        ctx.restore();

        cube.rotation += cube.rotationSpeed;
        cube.x += cube.speedX;
        cube.y += cube.speedY;

        if (cube.x < -cube.size || cube.x > canvas.width + cube.size) {
          cube.speedX *= -1;
        }
        if (cube.y < -cube.size || cube.y > canvas.height + cube.size) {
          cube.speedY *= -1;
        }
      });

      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      window.removeEventListener('resize', setCanvasSize);
      cancelAnimationFrame(animationId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full pointer-events-none z-0"
      style={{ height: '100%' }}
    />
  );
}
