import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Star, ChevronLeft, ChevronRight, Quote } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const testimonials = [
  {
    name: 'James Wilson',
    role: 'CEO at TechStart',
    company: 'TechStart',
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMGV4ZWN1dGl2ZSUyMENFTyUyMHBvcnRyYWl0fGVufDF8fHx8MTc4MjIyNzk1Nnww&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 5,
    text: 'DIGIT has been instrumental in scaling our development team. We found top-tier React developers within days, and the quality of work has been exceptional. The platform makes hiring seamless and secure.',
  },
  {
    name: 'Sarah Martinez',
    role: 'Founder at CreativeHub',
    company: 'CreativeHub',
    image: 'https://images.unsplash.com/photo-1553484771-0a615f264d58?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdGFydHVwJTIwZm91bmRlciUyMGVudHJlcHJlbmV1cnxlbnwxfHx8fDE3ODIyMjc5NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 5,
    text: "The talent pool on DIGIT is incredible. We've hired designers, developers, and marketing specialists - all of them have exceeded our expectations. The review system really helps in making informed decisions.",
  },
  {
    name: 'Michael Chen',
    role: 'Product Manager at InnovateCo',
    company: 'InnovateCo',
    image: 'https://images.unsplash.com/photo-1758691737644-ef8be18256c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb21wYW55JTIwbWFuYWdlciUyMHByb2Zlc3Npb25hbHxlbnwxfHx8fDE3ODIyMjc5NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
    rating: 5,
    text: 'Outstanding platform for finding specialized IT professionals. The search filters are precise, and the pricing is transparent. We saved months of recruitment time and found exactly the skills we needed.',
  },
];

export function Testimonials() {
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev + 1) % testimonials.length);
    }, 6000);

    return () => clearInterval(timer);
  }, []);

  const next = () => setCurrent((prev) => (prev + 1) % testimonials.length);
  const prev = () => setCurrent((prev) => (prev - 1 + testimonials.length) % testimonials.length);

  return (
    <section className="relative py-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
            Trusted by Growing Businesses
          </h2>
        </motion.div>

        <div className="relative max-w-4xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, x: 100 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -100 }}
              transition={{ duration: 0.5 }}
              className="backdrop-blur-md bg-white/5 border border-green-500/20 rounded-3xl p-8 md:p-12"
            >
              <Quote className="w-16 h-16 text-green-500/30 mb-6" />
              
              <div className="flex items-center gap-1 mb-6">
                {[...Array(testimonials[current].rating)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                ))}
              </div>

              <p className="text-gray-300 text-lg md:text-xl mb-8 leading-relaxed">
                "{testimonials[current].text}"
              </p>

              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-green-500/50">
                  <ImageWithFallback
                    src={testimonials[current].image}
                    alt={testimonials[current].name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <div className="text-white font-bold text-lg">
                    {testimonials[current].name}
                  </div>
                  <div className="text-gray-400">{testimonials[current].role}</div>
                </div>
                <div className="ml-auto">
                  <div className="text-green-400 font-bold text-lg">
                    {testimonials[current].company}
                  </div>
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <button
            onClick={prev}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 md:-translate-x-16 p-3 rounded-full bg-black/40 backdrop-blur-sm border border-green-500/30 hover:bg-green-500/20 hover:border-green-500 transition-all duration-300 group"
          >
            <ChevronLeft className="w-6 h-6 text-green-400 group-hover:scale-110 transition-transform" />
          </button>

          <button
            onClick={next}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 md:translate-x-16 p-3 rounded-full bg-black/40 backdrop-blur-sm border border-green-500/30 hover:bg-green-500/20 hover:border-green-500 transition-all duration-300 group"
          >
            <ChevronRight className="w-6 h-6 text-green-400 group-hover:scale-110 transition-transform" />
          </button>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrent(index)}
                className={`h-2 rounded-full transition-all duration-300 ${
                  index === current
                    ? 'w-8 bg-green-500'
                    : 'w-2 bg-white/30 hover:bg-white/50'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
