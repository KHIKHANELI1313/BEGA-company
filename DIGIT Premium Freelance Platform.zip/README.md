
  # DIGIT Premium Freelance Platform

  This is a code bundle for DIGIT Premium Freelance Platform. The original project is available at https://www.figma.com/design/A0VOBSdPxdvRHzRQxE7yw5/DIGIT-Premium-Freelance-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  