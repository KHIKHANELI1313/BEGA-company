import { AnimatedBackground } from './components/AnimatedBackground';
import { Navigation } from './components/Navigation';
import { HeroSlider } from './components/HeroSlider';
import { TrustedCompanies } from './components/TrustedCompanies';
import { Categories } from './components/Categories';
import { HowItWorks } from './components/HowItWorks';
import { Statistics } from './components/Statistics';
import { PriceEstimator } from './components/PriceEstimator';
import { Pricing } from './components/Pricing';
import { Testimonials } from './components/Testimonials';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="relative min-h-screen bg-black text-white overflow-x-hidden">
      {/* Fixed Animated Background */}
      <AnimatedBackground />

      {/* Main Content */}
      <div className="relative z-10">
        {/* Navigation */}
        <Navigation />

        {/* Hero Slider */}
        <HeroSlider />

        {/* Trusted Companies */}
        <TrustedCompanies />

        {/* Categories */}
        <Categories />

        {/* How It Works */}
        <HowItWorks />

        {/* Statistics */}
        <Statistics />

        {/* Price Estimator */}
        <PriceEstimator />

        {/* Pricing */}
        <Pricing />

        {/* Testimonials */}
        <Testimonials />

        {/* Footer */}
        <Footer />
      </div>
    </div>
  );
}
