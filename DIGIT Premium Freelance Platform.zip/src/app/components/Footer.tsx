import { motion } from 'motion/react';
import { Facebook, Instagram, Linkedin, Github, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';

export function Footer() {
  const footerSections = [
    {
      title: 'Company',
      links: ['About', 'Services', 'Categories', 'Support'],
    },
    {
      title: 'Legal',
      links: ['Privacy Policy', 'Terms', 'Contact'],
    },
    {
      title: 'Contact',
      links: [
        { icon: Mail, text: 'hello@digit.com' },
        { icon: Phone, text: '+1 (555) 123-4567' },
        { icon: MapPin, text: '123 Tech Street, San Francisco, CA 94102' },
      ],
    },
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Instagram, href: '#', label: 'Instagram' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Github, href: '#', label: 'GitHub' },
    { icon: Twitter, href: '#', label: 'Twitter' },
  ];

  return (
    <footer id="footer" className="relative pt-24 pb-12 border-t border-green-500/20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          {/* Brand & Newsletter */}
          <div className="lg:col-span-1">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
            >
              <h3 className="text-3xl font-bold bg-gradient-to-r from-green-400 to-green-600 bg-clip-text text-transparent mb-4">
                DIGIT
              </h3>
              <p className="text-gray-400 mb-6">
                The premium platform connecting businesses with top freelance talent worldwide.
              </p>

              <div className="space-y-3">
                <h4 className="text-white font-semibold">Stay Updated</h4>
                <div className="flex gap-2">
                  <Input
                    type="email"
                    placeholder="Your email"
                    className="bg-black/40 border-green-500/20 focus:border-green-500/50 text-white placeholder:text-gray-500"
                  />
                  <Button className="bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-black font-semibold">
                    Subscribe
                  </Button>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Footer Sections */}
          {footerSections.map((section, index) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
            >
              <h4 className="text-white font-bold text-lg mb-4">{section.title}</h4>
              <ul className="space-y-3">
                {section.links.map((link, idx) => {
                  if (typeof link === 'string') {
                    return (
                      <li key={idx}>
                        <a
                          href="#"
                          className="text-gray-400 hover:text-green-400 transition-colors"
                        >
                          {link}
                        </a>
                      </li>
                    );
                  } else {
                    const Icon = link.icon;
                    return (
                      <li key={idx} className="flex items-center gap-2 text-gray-400">
                        <Icon className="w-4 h-4 text-green-500" />
                        <span className="text-sm">{link.text}</span>
                      </li>
                    );
                  }
                })}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Social Links & Copyright */}
        <div className="pt-8 border-t border-green-500/20">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <motion.p
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="text-gray-400"
            >
              © 2026 DIGIT. All Rights Reserved.
            </motion.p>

            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              className="flex items-center gap-4"
            >
              {socialLinks.map((social) => {
                const Icon = social.icon;
                return (
                  <motion.a
                    key={social.label}
                    href={social.href}
                    whileHover={{ scale: 1.2, y: -3 }}
                    whileTap={{ scale: 0.9 }}
                    className="w-10 h-10 rounded-full bg-white/5 border border-green-500/20 flex items-center justify-center hover:bg-green-500/20 hover:border-green-500/40 transition-all duration-300 group"
                    aria-label={social.label}
                  >
                    <Icon className="w-5 h-5 text-gray-400 group-hover:text-green-400 transition-colors" />
                  </motion.a>
                );
              })}
            </motion.div>
          </div>
        </div>
      </div>
    </footer>
  );
}
