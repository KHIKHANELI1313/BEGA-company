import { useState } from 'react';
import { motion } from 'motion/react';
import { Star, MapPin, Clock, CheckCircle, Users } from 'lucide-react';
import { Badge } from './ui/badge';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface FreelancerCardProps {
  name: string;
  profession: string;
  bio: string;
  rating: number;
  skills: string[];
  country: string;
  hourlyRate: number;
  image: string;
  completedProjects: number;
  yearsExperience: number;
  successRate: number;
  reviews: number;
}

export function FreelancerCard({
  name,
  profession,
  bio,
  rating,
  skills,
  country,
  hourlyRate,
  image,
  completedProjects,
  yearsExperience,
  successRate,
  reviews,
}: FreelancerCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      whileHover={{ y: -5 }}
      className="backdrop-blur-md bg-white/5 border border-green-500/20 rounded-2xl p-6 hover:bg-white/10 hover:border-green-500/40 hover:shadow-2xl hover:shadow-green-500/20 transition-all duration-300"
    >
      <div className="flex flex-col md:flex-row gap-6">
        {/* Image Section */}
        <div
          className="relative w-full md:w-48 h-48 flex-shrink-0"
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          <motion.div
            className="w-full h-full rounded-xl overflow-hidden"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.3 }}
          >
            <ImageWithFallback
              src={image}
              alt={name}
              className="w-full h-full object-cover"
            />
          </motion.div>

          {/* Hover Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: isHovered ? 1 : 0 }}
            className="absolute inset-0 bg-black/90 backdrop-blur-sm rounded-xl flex items-center justify-center"
          >
            <div className="text-center p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-green-400 text-2xl font-bold">{completedProjects}</div>
                  <div className="text-gray-400 text-xs">Projects</div>
                </div>
                <div>
                  <div className="text-green-400 text-2xl font-bold">{yearsExperience}</div>
                  <div className="text-gray-400 text-xs">Years Exp.</div>
                </div>
                <div>
                  <div className="text-green-400 text-2xl font-bold">{successRate}%</div>
                  <div className="text-gray-400 text-xs">Success</div>
                </div>
                <div>
                  <div className="text-green-400 text-2xl font-bold">{reviews}</div>
                  <div className="text-gray-400 text-xs">Reviews</div>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Info Section */}
        <div className="flex-1">
          <div className="flex items-start justify-between mb-3">
            <div>
              <h3 className="text-xl font-bold text-white mb-1">{name}</h3>
              <p className="text-green-400 font-medium">{profession}</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold text-green-400">${hourlyRate}</div>
              <div className="text-gray-400 text-sm">/hour</div>
            </div>
          </div>

          <p className="text-gray-300 text-sm mb-4 line-clamp-2">{bio}</p>

          <div className="flex items-center gap-4 mb-4 text-sm">
            <div className="flex items-center gap-1 text-yellow-400">
              <Star className="w-4 h-4 fill-current" />
              <span className="font-semibold">{rating}</span>
            </div>
            <div className="flex items-center gap-1 text-gray-400">
              <MapPin className="w-4 h-4" />
              <span>{country}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            {skills.map((skill, index) => (
              <Badge
                key={index}
                className="bg-green-500/20 text-green-400 border border-green-500/30 hover:bg-green-500/30"
              >
                {skill}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
