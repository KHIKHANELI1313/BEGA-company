import { motion } from 'motion/react';
import { Search, Users, Shield, CheckCircle, Star } from 'lucide-react';

const steps = [
  {
    number: 1,
    title: 'Search Freelancers',
    description: 'Browse through thousands of verified professionals with the skills you need.',
    icon: Search,
  },
  {
    number: 2,
    title: 'Compare Profiles',
    description: 'Review portfolios, ratings, and experience to find the perfect match.',
    icon: Users,
  },
  {
    number: 3,
    title: 'Hire Safely',
    description: 'Secure contracts and payments through our protected platform.',
    icon: Shield,
  },
  {
    number: 4,
    title: 'Complete the Project',
    description: 'Collaborate effectively and track progress in real-time.',
    icon: CheckCircle,
  },
  {
    number: 5,
    title: 'Leave Reviews',
    description: 'Share your experience and help build a trusted community.',
    icon: Star,
  },
];

export function HowItWorks() {
  return (
    <section id="how-it-works" className="relative py-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
            How It Works
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Get started in minutes and find the perfect freelancer for your project
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Timeline */}
          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-green-500/50 via-green-500/30 to-transparent hidden md:block" />

            <div className="space-y-8">
              {steps.map((step, index) => {
                const Icon = step.icon;
                return (
                  <motion.div
                    key={step.number}
                    initial={{ opacity: 0, x: -50 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.1 }}
                    className="relative flex items-start gap-6 group"
                  >
                    {/* Icon Container */}
                    <div className="relative z-10 flex-shrink-0">
                      <motion.div
                        whileHover={{ scale: 1.1, rotate: 5 }}
                        className="w-16 h-16 rounded-2xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center shadow-lg shadow-green-500/50 group-hover:shadow-green-500/70 transition-all duration-300"
                      >
                        <Icon className="w-8 h-8 text-white" />
                      </motion.div>
                      <div className="absolute -bottom-2 -right-2 w-8 h-8 rounded-full bg-black border-2 border-green-500 flex items-center justify-center text-green-400 font-bold text-sm">
                        {step.number}
                      </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 pt-2">
                      <h3 className="text-xl font-bold text-white mb-2 group-hover:text-green-400 transition-colors">
                        {step.title}
                      </h3>
                      <p className="text-gray-400">{step.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* Video/Illustration Side */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-video rounded-3xl overflow-hidden backdrop-blur-md bg-gradient-to-br from-green-500/20 to-purple-500/20 border border-green-500/30 shadow-2xl shadow-green-500/20">
              {/* Animated illustration */}
              <div className="w-full h-full flex items-center justify-center relative overflow-hidden">
                {/* Floating elements */}
                <motion.div
                  animate={{
                    y: [0, -20, 0],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                  className="absolute top-10 left-10 w-20 h-20 rounded-2xl bg-gradient-to-br from-green-400 to-green-600 shadow-lg shadow-green-500/50"
                />
                
                <motion.div
                  animate={{
                    y: [0, 20, 0],
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    ease: 'easeInOut',
                    delay: 0.5,
                  }}
                  className="absolute bottom-10 right-10 w-16 h-16 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 shadow-lg shadow-purple-500/50"
                />

                <motion.div
                  animate={{
                    scale: [1, 1.1, 1],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
                >
                  <div className="w-32 h-32 rounded-3xl bg-gradient-to-br from-green-500 to-green-600 flex items-center justify-center shadow-2xl shadow-green-500/50">
                    <CheckCircle className="w-16 h-16 text-white" />
                  </div>
                </motion.div>

                {/* Orbiting elements */}
                <motion.div
                  animate={{
                    rotate: 360,
                  }}
                  transition={{
                    duration: 20,
                    repeat: Infinity,
                    ease: 'linear',
                  }}
                  className="absolute inset-0"
                >
                  <div className="absolute top-1/4 left-1/4 w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-400 to-cyan-600 shadow-lg shadow-cyan-500/50" />
                </motion.div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
