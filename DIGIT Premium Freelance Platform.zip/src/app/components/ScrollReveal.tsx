import { useEffect, useRef, ReactNode } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface ScrollRevealProps {
  children: ReactNode;
  direction?: 'up' | 'down' | 'left' | 'right';
  delay?: number;
}

export function ScrollReveal({
  children,
  direction = 'up',
  delay = 0,
}: ScrollRevealProps) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!ref.current) return;

    const startValues: any = {
      opacity: 0,
    };

    switch (direction) {
      case 'up':
        startValues.y = 50;
        break;
      case 'down':
        startValues.y = -50;
        break;
      case 'left':
        startValues.x = 50;
        break;
      case 'right':
        startValues.x = -50;
        break;
    }

    gsap.fromTo(
      ref.current,
      startValues,
      {
        opacity: 1,
        x: 0,
        y: 0,
        duration: 1,
        delay,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: ref.current,
          start: 'top 80%',
          toggleActions: 'play none none reverse',
        },
      }
    );
  }, [direction, delay]);

  return <div ref={ref}>{children}</div>;
}
