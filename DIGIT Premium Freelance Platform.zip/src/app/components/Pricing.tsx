import { motion } from 'motion/react';
import { Check, Star } from 'lucide-react';
import { Button } from './ui/button';

const plans = [
  {
    name: 'Basic',
    description: 'For one-time and short-term projects',
    price: 'Free',
    features: [
      'Access to freelancer database',
      'Profiles and ratings',
      'Messaging',
      'Job posting',
      'Secure payments',
    ],
    cta: 'Start Now',
    popular: false,
  },
  {
    name: 'Business Plus',
    description: 'For permanent hiring and growing teams',
    price: '$49',
    priceDetail: '/month',
    features: [
      'Everything in Basic',
      'Priority job listings',
      'Recommended top candidates',
      'Branded company profile',
      'Team management tools',
      'Analytics dashboard',
      'Priority support',
    ],
    cta: 'Start Now',
    popular: true,
  },
];

export function Pricing() {
  return (
    <section className="relative py-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
            Choose How You Want to Hire
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Flexible plans for every business
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className={`relative backdrop-blur-md bg-white/5 rounded-3xl p-8 transition-all duration-300 ${
                plan.popular
                  ? 'border-2 border-green-500 shadow-2xl shadow-green-500/30'
                  : 'border border-green-500/20 hover:border-green-500/40'
              }`}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="bg-gradient-to-r from-green-500 to-green-600 px-6 py-2 rounded-full flex items-center gap-2 shadow-lg shadow-green-500/50">
                    <Star className="w-4 h-4 text-white fill-white" />
                    <span className="text-white font-bold text-sm">Most Popular</span>
                  </div>
                </div>
              )}

              <div className="mb-8">
                <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
                <p className="text-gray-400">{plan.description}</p>
              </div>

              <div className="mb-8">
                <div className="flex items-baseline gap-2">
                  <span className="text-5xl font-bold bg-gradient-to-r from-green-400 to-green-600 bg-clip-text text-transparent">
                    {plan.price}
                  </span>
                  {plan.priceDetail && (
                    <span className="text-gray-400 text-lg">{plan.priceDetail}</span>
                  )}
                </div>
              </div>

              <div className="space-y-4 mb-8">
                {plan.features.map((feature, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="flex-shrink-0 w-5 h-5 rounded-full bg-green-500/20 flex items-center justify-center mt-0.5">
                      <Check className="w-3 h-3 text-green-400" />
                    </div>
                    <span className="text-gray-300">{feature}</span>
                  </div>
                ))}
              </div>

              <Button
                className={`w-full py-6 text-lg font-semibold transition-all duration-300 ${
                  plan.popular
                    ? 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-black shadow-lg shadow-green-500/50 hover:shadow-green-500/70 hover:scale-105'
                    : 'bg-white/10 hover:bg-white/20 text-white border border-green-500/30 hover:border-green-500/50'
                }`}
              >
                {plan.cta}
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
