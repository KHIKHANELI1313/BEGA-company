import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Brain,
  Code,
  Palette,
  TrendingUp,
  FileText,
  Headphones,
  DollarSign,
  Scale,
  Users,
  Wrench,
  ChevronDown,
} from 'lucide-react';
import { FreelancerCard } from './FreelancerCard';

const categories = [
  { name: 'AI Services', icon: Brain, color: 'from-purple-500 to-pink-500' },
  { name: 'Development & IT', icon: Code, color: 'from-blue-500 to-cyan-500' },
  { name: 'Design & Creative', icon: Palette, color: 'from-pink-500 to-rose-500' },
  { name: 'Sales & Marketing', icon: TrendingUp, color: 'from-orange-500 to-yellow-500' },
  { name: 'Writing & Translation', icon: FileText, color: 'from-green-500 to-emerald-500' },
  { name: 'Admin & Support', icon: Headphones, color: 'from-indigo-500 to-purple-500' },
  { name: 'Finance & Accounting', icon: DollarSign, color: 'from-green-600 to-teal-500' },
  { name: 'Legal', icon: Scale, color: 'from-gray-500 to-slate-500' },
  { name: 'HR & Training', icon: Users, color: 'from-red-500 to-orange-500' },
  { name: 'Engineering & Architecture', icon: Wrench, color: 'from-cyan-500 to-blue-500' },
];

const freelancers = [
  {
    name: 'Sarah Johnson',
    profession: 'Senior Frontend Developer',
    bio: 'Specialized in React, Next.js, and modern web technologies. 10+ years of experience building scalable applications.',
    rating: 4.9,
    skills: ['React', 'TypeScript', 'Next.js', 'Tailwind'],
    country: 'United States',
    hourlyRate: 85,
    image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBidXNpbmVzcyUyMHBlcnNvbiUyMHBvcnRyYWl0fGVufDF8fHx8MTc4MjE0NDY5N3ww&ixlib=rb-4.1.0&q=80&w=1080',
    completedProjects: 247,
    yearsExperience: 10,
    successRate: 98,
    reviews: 182,
  },
  {
    name: 'Michael Chen',
    profession: 'Full Stack Developer',
    bio: 'Expert in Node.js, Python, and cloud architecture. Building robust backend systems and APIs.',
    rating: 5.0,
    skills: ['Node.js', 'Python', 'AWS', 'MongoDB'],
    country: 'Canada',
    hourlyRate: 95,
    image: 'https://images.unsplash.com/photo-1566753323558-f4e0952af115?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWNoJTIwcHJvZmVzc2lvbmFsJTIwZGV2ZWxvcGVyJTIwcG9ydHJhaXR8ZW58MXx8fHwxNzgyMjI3ODE0fDA&ixlib=rb-4.1.0&q=80&w=1080',
    completedProjects: 315,
    yearsExperience: 12,
    successRate: 100,
    reviews: 256,
  },
  {
    name: 'Emma Williams',
    profession: 'UI/UX Designer',
    bio: 'Creative designer focused on user-centered design and creating beautiful digital experiences.',
    rating: 4.8,
    skills: ['Figma', 'Adobe XD', 'Prototyping', 'User Research'],
    country: 'United Kingdom',
    hourlyRate: 75,
    image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjcmVhdGl2ZSUyMGRlc2lnbmVyJTIwcHJvZmVzc2lvbmFsfGVufDF8fHx8MTc4MjIyNzgxNHww&ixlib=rb-4.1.0&q=80&w=1080',
    completedProjects: 189,
    yearsExperience: 8,
    successRate: 97,
    reviews: 143,
  },
];

export function Categories() {
  const [expandedCategory, setExpandedCategory] = useState<string | null>(null);

  return (
    <section id="categories" className="relative py-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
            Find Freelancers by Category
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-12">
          {categories.map((category, index) => {
            const Icon = category.icon;
            const isExpanded = expandedCategory === category.name;

            return (
              <motion.div
                key={category.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.05 }}
                className={`${isExpanded ? 'md:col-span-2 lg:col-span-5' : ''}`}
              >
                <motion.button
                  onClick={() => setExpandedCategory(isExpanded ? null : category.name)}
                  whileHover={{ scale: 1.02, y: -5 }}
                  whileTap={{ scale: 0.98 }}
                  className={`w-full p-6 backdrop-blur-md bg-white/5 border border-green-500/20 rounded-2xl hover:bg-white/10 hover:border-green-500/40 transition-all duration-300 group relative overflow-hidden ${
                    isExpanded ? 'bg-white/10 border-green-500/40' : ''
                  }`}
                >
                  <div className={`absolute inset-0 bg-gradient-to-br ${category.color} opacity-0 group-hover:opacity-10 transition-opacity duration-300`} />
                  
                  <div className="relative">
                    <div className="flex items-center justify-between mb-3">
                      <div className={`p-3 rounded-xl bg-gradient-to-br ${category.color} shadow-lg`}>
                        <Icon className="w-6 h-6 text-white" />
                      </div>
                      <motion.div
                        animate={{ rotate: isExpanded ? 180 : 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <ChevronDown className="w-5 h-5 text-green-400" />
                      </motion.div>
                    </div>
                    <h3 className="text-white font-semibold text-left group-hover:text-green-400 transition-colors">
                      {category.name}
                    </h3>
                  </div>
                </motion.button>

                {/* Expanded Freelancer Cards */}
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.3 }}
                      className="mt-4 space-y-4"
                    >
                      {freelancers.map((freelancer, idx) => (
                        <FreelancerCard key={idx} {...freelancer} />
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
