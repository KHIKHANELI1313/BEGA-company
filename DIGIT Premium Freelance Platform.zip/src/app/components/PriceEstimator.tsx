import { useState } from 'react';
import { motion } from 'motion/react';
import { Search, DollarSign } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const skillData = [
  { skill: 'React', avgRate: 85, minRate: 50, maxRate: 150 },
  { skill: 'Node.js', avgRate: 90, minRate: 55, maxRate: 160 },
  { skill: 'Python', avgRate: 95, minRate: 60, maxRate: 170 },
  { skill: 'UI/UX Design', avgRate: 75, minRate: 45, maxRate: 130 },
  { skill: 'Mobile Dev', avgRate: 100, minRate: 65, maxRate: 180 },
  { skill: 'DevOps', avgRate: 110, minRate: 70, maxRate: 200 },
];

export function PriceEstimator() {
  const [selectedSkill, setSelectedSkill] = useState('React');
  const [hours, setHours] = useState([40]);

  const currentSkillData = skillData.find((s) => s.skill === selectedSkill) || skillData[0];
  const estimatedCost = currentSkillData.avgRate * hours[0];

  return (
    <section className="relative py-24">
      <div className="max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-white to-green-400 bg-clip-text text-transparent">
            Find Freelancers for Every Type of Work
          </h2>
          <p className="text-gray-400 text-lg max-w-2xl mx-auto">
            Get average freelancer pricing based on the skills you need
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Calculator */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="backdrop-blur-md bg-white/5 border border-green-500/20 rounded-3xl p-8"
          >
            <h3 className="text-2xl font-bold text-white mb-6">Calculate Your Budget</h3>

            <div className="space-y-6">
              {/* Search Skills */}
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Search Skills</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    placeholder="Search for skills..."
                    className="pl-10 bg-black/40 border-green-500/20 focus:border-green-500/50 text-white"
                  />
                </div>
              </div>

              {/* Skill Selection */}
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Select Skill</label>
                <Select value={selectedSkill} onValueChange={setSelectedSkill}>
                  <SelectTrigger className="bg-black/40 border-green-500/20 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-black border-green-500/20">
                    {skillData.map((skill) => (
                      <SelectItem key={skill.skill} value={skill.skill} className="text-white">
                        {skill.skill}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {/* Hours Slider */}
              <div>
                <label className="text-sm text-gray-400 mb-2 block">
                  Estimated Hours: <span className="text-green-400 font-bold">{hours[0]}h</span>
                </label>
                <Slider
                  value={hours}
                  onValueChange={setHours}
                  min={1}
                  max={200}
                  step={1}
                  className="py-4"
                />
              </div>

              {/* Price Range */}
              <div className="bg-black/40 rounded-2xl p-6 border border-green-500/20">
                <div className="flex items-center justify-between mb-4">
                  <span className="text-gray-400">Average Rate</span>
                  <span className="text-green-400 font-bold text-xl">
                    ${currentSkillData.avgRate}/hr
                  </span>
                </div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-gray-400">Range</span>
                  <span className="text-gray-300">
                    ${currentSkillData.minRate} - ${currentSkillData.maxRate}/hr
                  </span>
                </div>
                <div className="pt-4 border-t border-green-500/20">
                  <div className="flex items-center justify-between">
                    <span className="text-white font-semibold text-lg">Estimated Total</span>
                    <span className="text-green-400 font-bold text-3xl">
                      ${estimatedCost.toLocaleString()}
                    </span>
                  </div>
                </div>
              </div>

              <Button className="w-full bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-black font-semibold text-lg py-6">
                Find Freelancers
              </Button>
            </div>
          </motion.div>

          {/* Chart */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="backdrop-blur-md bg-white/5 border border-green-500/20 rounded-3xl p-8"
          >
            <h3 className="text-2xl font-bold text-white mb-6">Average Rates by Skill</h3>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={skillData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#22C55E20" />
                <XAxis dataKey="skill" stroke="#9CA3AF" angle={-45} textAnchor="end" height={100} />
                <YAxis stroke="#9CA3AF" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#000',
                    border: '1px solid #22C55E40',
                    borderRadius: '12px',
                  }}
                  labelStyle={{ color: '#22C55E' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Bar dataKey="avgRate" radius={[8, 8, 0, 0]}>
                  {skillData.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={entry.skill === selectedSkill ? '#22C55E' : '#22C55E60'}
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
